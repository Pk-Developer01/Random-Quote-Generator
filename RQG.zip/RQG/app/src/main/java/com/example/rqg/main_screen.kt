package com.example.rqg

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class main_screen : AppCompatActivity() {

    private lateinit var quoteTextView: TextView
    private lateinit var generateButton: Button
    private lateinit var shareButton: Button
    private lateinit var toolbar: Toolbar // Declare but do not initialize here

    private val quotes = listOf(
        Quote("Be yourself; everyone else is already taken.", "Oscar Wilde"),
        Quote("Two things are infinite: the universe and human stupidity; and I'm not sure about the universe.", "Albert Einstein"),
        Quote("In three words I can sum up everything I've learned about life: it goes on.", "Robert Frost"),
        Quote("You only live once, but if you do it right, once is enough.", "Mae West"),
        Quote("To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment.", "Ralph Waldo Emerson"),
        Quote("In the end, we will remember not the words of our enemies, but the silence of our friends.", "Martin Luther King Jr."),
        Quote("The only thing we have to fear is fear itself.", "Franklin D. Roosevelt"),
        Quote("Do not dwell in the past, do not dream of the future, concentrate the mind on the present moment.", "Buddha"),
        Quote("Life is what happens when you're busy making other plans.", "John Lennon"),
        Quote("Success is not final, failure is not fatal: It is the courage to continue that counts.", "Winston Churchill"),
        Quote("It is better to be hated for what you are than to be loved for what you are not.", "André Gide"),
        Quote("I have not failed. I've just found 10,000 ways that won't work.", "Thomas Edison"),
        Quote("The only way to do great work is to love what you do.", "Steve Jobs"),
        Quote("If you want to live a happy life, tie it to a goal, not to people or things.", "Albert Einstein"),
        Quote("The purpose of our lives is to be happy.", "Dalai Lama"),
        Quote("Life is really simple, but we insist on making it complicated.", "Confucius"),
        Quote("May you live all the days of your life.", "Jonathan Swift"),
        Quote("Life itself is the most wonderful fairy tale.", "Hans Christian Andersen"),
        Quote("Do not take life too seriously. You will never get out of it alive.", "Elbert Hubbard"),
        Quote("Do what you can, with what you have, where you are.", "Theodore Roosevelt"),
        Quote("You must be the change you wish to see in the world.", "Mahatma Gandhi"),
        Quote("The best way to predict your future is to create it.", "Abraham Lincoln"),
        Quote("If you tell the truth, you don't have to remember anything.", "Mark Twain"),
        Quote("Not all those who wander are lost.", "J.R.R. Tolkien"),
        Quote("To live is the rarest thing in the world. Most people exist, that is all.", "Oscar Wilde"),
        Quote("It does not do to dwell on dreams and forget to live.", "J.K. Rowling"),
        Quote("The only limit to our realization of tomorrow is our doubts of today.", "Franklin D. Roosevelt"),
        Quote("The journey of a thousand miles begins with one step.", "Lao Tzu"),
        Quote("Life is what we make it, always has been, always will be.", "Grandma Moses"),
        Quote("Keep your face always toward the sunshine—and shadows will fall behind you.", "Walt Whitman"),
        Quote("Believe you can and you're halfway there.", "Theodore Roosevelt"),
        Quote("The future belongs to those who believe in the beauty of their dreams.", "Eleanor Roosevelt"),
        Quote("The best way to find yourself is to lose yourself in the service of others.", "Mahatma Gandhi"),
        Quote("The mind is everything. What you think you become.", "Buddha"),
        Quote("Happiness is not something ready made. It comes from your own actions.", "Dalai Lama"),
        Quote("Life is short, and it is up to you to make it sweet.", "Sarah Louise Delany"),
        Quote("Everything has beauty, but not everyone sees it.", "Confucius"),
        Quote("Do not go where the path may lead, go instead where there is no path and leave a trail.", "Ralph Waldo Emerson"),
        Quote("In the end, it's not the years in your life that count. It's the life in your years.", "Abraham Lincoln"),
        Quote("You have within you right now, everything you need to deal with whatever the world can throw at you.", "Brian Tracy"),
        Quote("What lies behind us and what lies before us are tiny matters compared to what lies within us.", "Ralph Waldo Emerson"),
        Quote("The only impossible journey is the one you never begin.", "Tony Robbins"),
        Quote("Act as if what you do makes a difference. It does.", "William James"),
        Quote("Don't judge each day by the harvest you reap but by the seeds that you plant.", "Robert Louis Stevenson"),
        Quote("The greatest glory in living lies not in never falling, but in rising every time we fall.", "Nelson Mandela"),
        Quote("Your time is limited, so don't waste it living someone else's life.", "Steve Jobs"),
        Quote("In the end, we only regret the chances we didn't take.", "Lewis Carroll"),
        Quote("Everything you’ve ever wanted is on the other side of fear.", "George Addair"),
        Quote("Hardships often prepare ordinary people for an extraordinary destiny.", "C.S. Lewis")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_screen)

        // Initialize toolbar after setContentView
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Random Quote Generator\n"

        quoteTextView = findViewById(R.id.quoteTextView)
        generateButton = findViewById(R.id.generateButton)
        shareButton = findViewById(R.id.shareButton)

        generateButton.setOnClickListener {
            displayRandomQuote()
        }

        shareButton.setOnClickListener {
            shareQuote()
        }

        // Display initial quote on app launch
        displayRandomQuote()
    }

    private fun displayRandomQuote() {
        val randomQuote = getRandomQuote()
        quoteTextView.text = "\"${randomQuote.text}\"\n\t\t ->${randomQuote.author}"
    }

    private fun getRandomQuote(): Quote {
        val randomIndex = (0 until quotes.size).random()
        return quotes[randomIndex]
    }

    private fun shareQuote() {
        val quoteText = quoteTextView.text.toString()
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, quoteText)
            type = "text/plain"
        }
        startActivity(Intent.createChooser(shareIntent, "Share Quote"))
    }
}

data class Quote(val text: String, val author: String)
